# NYC Property Record — 235 East 40th Street, Unit 17E

A static, publicly accessible webpage documenting a 2025 real-estate transaction in Manhattan, sourced entirely from official NYC Department of Finance ACRIS records.

## What This Is

A factual summary of publicly recorded property documents for:

- **Property:** 235 East 40th Street, Unit 17E, New York, NY 10016
- **Buyers:** Goutham Goli and Pranathi Goli
- **Seller:** Shiaw-Chun Shang
- **Recorded:** September 2, 2025

## What This Is NOT

- Not an official government website
- Not a news article or independent reporting
- Not legal or financial advice

## Data Source

All information is extracted from documents filed with the **New York City Department of Finance** and publicly available through [ACRIS](https://a836-acris.nyc.gov/CP/) (Automated City Register Information System).

## Files

| File | Purpose |
|------|---------|
| `index.html` | Main property record page |
| `styles.css` | Stylesheet |
| `robots.txt` | Search-engine crawl directives |
| `sitemap.xml` | Sitemap for search-engine submission |
| `404.html` | Custom error page |
| `README.md` | This file |

## Deployment (GitHub Pages)

1. Create a GitHub account at [github.com](https://github.com).
2. Create a **new repository** (green "New" button or "+" menu at the top right).
3. Name the repository (e.g., `nyc-property-record`). Set visibility to **Public**.
4. Upload all files from this project **at the repository root** (not inside a subfolder).
5. Go to **Settings** > **Pages**.
6. Under **Source**, select **Deploy from a branch**.
7. Choose the **main** branch, **/ (root)** folder, and click **Save**.
8. Your site will be live at `https://YOUR-USERNAME.github.io/YOUR-REPO-NAME/` within a few minutes.

### After Deployment — Update Placeholder URLs

Search-and-replace the following placeholder strings in `index.html`, `robots.txt`, and `sitemap.xml` with your actual GitHub Pages URL:

```
https://YOUR-USERNAME.github.io/YOUR-REPO-NAME/
```

Replace with your real URL, e.g.:

```
https://janedoe.github.io/nyc-property-record/
```

## License

The underlying public records are government documents. This webpage summarizing them is provided as-is.
